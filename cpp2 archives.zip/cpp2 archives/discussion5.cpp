#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
	double num1 = -22.22;

	cout << endl << "The absolute value of your number is: " << fixed << fabs(num1) << endl;

	system("pause");
	return 0;
}