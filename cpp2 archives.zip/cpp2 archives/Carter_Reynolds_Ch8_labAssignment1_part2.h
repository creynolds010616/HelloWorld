/* Student: Carter Reynolds
	Assignment Description: This program prompts the user to enter how many grades to be calculated, creates an array to hold each grade, 
							calculates the average and multiplies that by 30%. 
	Assignment Name: Chapter 8 - Lab Assignment 1
	Due Date: 9/4/18
*/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int totalGrades = 10; 
	
	cout << "Enter the total number of grades: \n"; 
	cin >> totalGrades;

	double gradesArray[totalGrades];

	for (int index = 0; index < totalGrades; index++)
	{
		cin >> gradesArray[index];
	}

	double gradeTotal = 0.00;

	for (int index = 0; index < totalGrades; index++)
	{
		double gradeTotal = gradesArray[index] + gradeTotal;
	}

	double gradeAverage = gradeTotal / 5;

	double gradeAverage30 = gradeAverage * .30;

	gradeAverage30;

	cout << endl;
	system("pause");
	return 0;
}

