//***********************************************************************************************************************************************
//		
//		Carter Reynolds
//
//		Chapter 10 - Lab 2:
//
//		File name: employeeType.h
//
//		Description: This is the header file, which will declare the class employeeType.
//						
//
//		
//
//***********************************************************************************************************************************************

#include <iostream>
#include <iomanip>
#include <string>
#include <stdlib.h>
#include <Windows.h>
using namespace std;


#pragma once

class employeeType
{
private:
	string name;
	int idNum;
	string department;
	string position; 
public: 
	employeeType(string NAME, int ID, string DEPT, string POS); 
	/*	Initializes class employeeType with the formal parameters
		postcondition: name = NAME
					   idNum = ID
					   department = DEPT
					   position = POS
	*/
	employeeType(string NAME, int ID);
	//	Initializes the formal parameters to the class employeeType name and idNum, repectively, department and position will be null. 

	employeeType();
	// Initializes name, department, and position to a null string; idNum is 0.
	
	//~employeeType();
	// Deconstructor.

	void setName(string NAME);
	// Sets name to the parameter.

	void setIDnum(int ID);
	// Sets idNum to the formal parameter.

	void setDept(string DEPT);
	// Sets department to the formal parameter.

	void setPos(string POS);
	// Sets position to the formal parameter. 

	string getName(); 
	int getIDnum();
	string getDept();
	string getPos();
	
	void displayEmployee(employeeType); 
};



