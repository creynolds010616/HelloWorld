/*
	Carter Reynolds		

		Chapter 14 - Lab Assignment 1

		Description: This program will handle an exception for a user-entered negative number.

		Due: 11/27/2018
*/

#include <iostream>
#include <string>

using namespace std;

int main()
{
	int a, b;
	
	try
	{
		cout << "Enter feet: ";
		cin >> a;

		if (a <= 0)
			throw string("Invalid dimension: feet");
		
		cout << endl << "Enter inches: ";
		cin >> b;

		if (b <= 0)
			throw string("Invalid dimension: inches");

	}

	catch (string s)
	{
		cout << s << endl;
	}

	cout << endl;
	cout << "Length: " << a << endl
		 << "Inches: " << b << endl;

	system("pause");
	return 0;
}
