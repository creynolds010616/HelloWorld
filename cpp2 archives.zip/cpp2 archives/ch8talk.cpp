#include <iostream>
#include <string>

using namespace std; 

int main()
{
	int array[2][2]; //= {{10, 22}, {31213, 433} };		
	
	// for (int i = 0; i < 2; i++)
		//for (int j = 0; j < 2; j++)
			//cin >> array[i][j];
	
	array[2][2] = 5; 
	for (int i = 0; i < 2; i++)
		for (int j = 0; j < 2; j++)
			cout << array[i][j] << " ";

	cout << endl; 
	system("pause");
	return 0;
}