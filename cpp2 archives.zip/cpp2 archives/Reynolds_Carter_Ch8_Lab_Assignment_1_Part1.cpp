#include <iostream>

using namespace std; 

//function prototype
int negativeCount(double myArray[4]);

int main()
{
	double doubleNegative[4] = { -1, -2, -3, 4 }; //there are three negative numbers in the array

	cout << negativeCount(doubleNegative) << endl; 

	system("pause");
	return 0;
}

int negativeCount(double myArray[4]) //this function will count the negative numbers in an Array. 
{
	int count_of_negative_numbers_in_array = 0; 

	for (int index = 0; index < 4; index++)
	{
		if (myArray[index] < 0)
			count_of_negative_numbers_in_array++;
		
	}
	
	cout << "The array has " <<  count_of_negative_numbers_in_array << " negative numbers. \n";
	return 0;
}