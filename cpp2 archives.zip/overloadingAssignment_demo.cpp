/*
Carter Reynolds

Programming Assignment IV - Overloading

Due Date : 11 / 14 / 2018

File Name: overloadingAssignment_demo.cpp

Description : 

This demo program will create a class monthType object, demo1. The values of demo1, the month name and number, will be changed

via the set function, the post and deincrement overloaded functions, and the updateName and updateNumber functions. Finally,

the program will create a monthType object with an invalid name, invalidName, with the "january" arguement--which is invalid. 

the program will promt the user for another name untill a valid name has been entered. 
*/
#include "monthType.h"

using namespace std;


ostream& operator<<(ostream& osObject, const monthType& monthTypeObj);

monthType operator++(monthType& incObj, int u);
monthType operator--(monthType& incObj, int u);


int main()
{
	int userNum;
	
	cout << "Creating demo1 object from monthType. \n";

	monthType demo1; //demo class monthType obj 1.
	cout << endl;

	cout << demo1++ << endl;
	//demo1.updateName();

	cout << "post increment operator has executed. \n";
	cout << demo1 << endl;

	cout << "Enter a number between 1 and 12 for the corresponding month name: ";
	cin >> userNum;
	
	cout << endl; 

	demo1.setNumber(userNum);
	cout << demo1 << endl;
	
	cout << "Executing demo1.setNumber(12)" << endl;
	demo1.setNumber(12);

	cout << demo1 << endl;

	cout << "Executing demo++ \n";
	demo1++;
	
	cout << demo1 << endl;
	
	cout << "Executing demo-- \n";
	demo1--;
	cout << demo1 << endl;

	cout << "The values of demo1 are: \n";
	cout << demo1 << endl;

	cout << "Now printing the next eight months. \n";

	inc_next_month_Print(demo1);
	
	cout << "Executing demo1.setNumber(2) \n";

	demo1.setNumber(2);

	cout << endl << "Now printing the last eight months \n";

	dec_next_month_Print(demo1);

	//cout << endl;
	cout << endl << "Finally, we will demonstrate the invalid name verification. \n"
		 << "Creating a new class monthType object invalidName('january') \n" << endl;

	monthType invalidName("january");

	cout << endl;
	cout << invalidName;
	

	system("pause");
	return 0;
}

ostream& operator<<(ostream& osObject, const monthType& monthTypeObj)
{
	cout << "Month Name: " << monthTypeObj.name << endl;
	cout << "Month Numb: " << monthTypeObj.mNum << endl;

	return osObject;
}

monthType operator++(monthType& incObj, int u)
{
	monthType temp;
	temp.mNum = incObj.mNum;

	if (incObj.mNum == 12)
	{
		incObj.setNumber(1);
		incObj.updateName();
	}

	else
	{
		(incObj.mNum)++;
		incObj.updateName();
	}
	return temp;
}

monthType operator--(monthType& incObj, int u)
{
	monthType temp;

	temp.mNum = incObj.mNum;

	if (incObj.mNum == 1)
	{
		incObj.setNumber(12);
		incObj.updateName();
	}
	else
	{
		(incObj.mNum)--;
		incObj.updateName();
	}

	return temp;
}

void inc_next_month_Print(monthType& monthTypeObj)
{
	cout << "The next eight months are: \n";
	monthTypeObj++;
	for (int i = 0; i < 8; i++)
	{
		cout << monthTypeObj << endl;
		monthTypeObj++;
	}
}

void dec_next_month_Print(monthType& monthTypeObj)
{
	cout << "The previous eigth months are: \n";
	monthTypeObj--;
	for (int i = 0; i < 8; i++)
	{
		cout << monthTypeObj << endl;
		monthTypeObj--;
	}
}