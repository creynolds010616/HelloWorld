/*
Carter Reynolds

Programming Assignment IV - Overloading

Due Date: 11/14/2018

File Name: monthType_imp.cpp

Description:	

*/
#include "monthType.h"

monthType::monthType()
{
	mNum = 1;
	name = "January";
}

monthType::monthType(string m)
{ 
	if (!(m == "January" || m == "February" || m == "March" || m == "April" || m == "May" || m == "June"
		|| m == "July" || m == "August" || m == "September" || m == "October" || m == "November" ||
		m == "December"))
	{
		while (!(m == "January" || m == "February" || m == "March" || m == "April" || m == "May" || m == "June"
			|| m == "July" || m == "August" || m == "September" || m == "October" || m == "November" ||
			m == "December"))
		{
			cout << "Invalid month. Enter a month name beginning with a capital letter. \n";
			cin >> m;

			cout << endl;

		}

		name = m;
		updateNumber();

	}

	else
		name = m;

	updateNumber();
	updateName(); // a double-check that everything is updated...


	/*else
		name = m;
	
	if (name == "January")
		mNum = 1;
	else if (name == "February")
		mNum = 2;
	else if (name == "March")
		mNum = 3;
	else if (name == "April")
		mNum = 4;
	else if (name == "May")
		mNum = 5;
	else if (name == "June")
		mNum = 6;
	else if (name == "July")
		mNum = 7;
	else if (name == "August")
		mNum = 8;
	else if (name == "September")
		mNum = 9;
	else if (name == "October")
		mNum = 10;
	else if (name == "November")
		mNum = 11;
	else if (name == "December")
		mNum = 12;
	else
		mNum = 1;*/

	/*cout << "Enter the month beginning with a capital letter. "
	<< "For example, 'January' is acceptable, while 'january' will not be accepted. \n";
	cin >> name;
	while (!(name == "January" || name == "February" || name == "March" || name == "April" || name == "May" || name))
	{
	cout << "The month you have entered is invalid, please enter another month.";
	}*/

}

monthType::monthType(int n)
{
	if (n < 0 || n > 12)
	{
		while (n < 0 || n > 12)
		{
			cout << "Month number is out of range. Enter a number between 1 and 12 to continue:	";
			cin >> n;
			cout << endl << endl;
		}
		mNum = n;
	}
	
	mNum = n;
	

	if (mNum == 1)
		name = "January";
	else if (mNum == 2)
		name = "February";
	else if (mNum == 3)
		name = "March";
	else if (mNum == 4)
		name = "April";
	else if (mNum == 5)
		name = "May";
	else if (mNum == 6)
		name = "June";
	else if (mNum == 7)
		name = "July";
	else if (mNum == 8)
		name = "August";
	else if (mNum == 9)
		name = "September";
	else if (mNum == 10)
		name = "October";
	else if (mNum == 11)
		name = "November";
	else if (mNum == 12)
		name = "December";
}

void monthType::setName(string m) { name = m; updateNumber(); }

void monthType::setNumber(int n) { mNum = n; updateName(); }

string monthType::getName() { return name; }

int monthType::getNumber() { return mNum; }

void monthType::updateName()
{
	while (mNum < 0 || mNum > 12)
	{
		cout << "Month number is out of range. Enter a number between 1 and 12 to continue:	";
		cin >> mNum;
		cout << endl << endl;
	}

	if (mNum == 1)
		name = "January";
	else if (mNum == 2)
		name = "February";
	else if (mNum == 3)
		name = "March";
	else if (mNum == 4)
		name = "April";
	else if (mNum == 5)
		name = "May";
	else if (mNum == 6)
		name = "June";
	else if (mNum == 7)
		name = "July";
	else if (mNum == 8)
		name = "August";
	else if (mNum == 9)
		name = "September";
	else if (mNum == 10)
		name = "October";
	else if (mNum == 11)
		name = "November";
	else if (mNum == 12)
		name = "December";
}

void monthType::updateNumber()
{
	if (name == "January")
		mNum = 1;
	else if (name == "February")
		mNum = 2;
	else if (name == "March")
		mNum = 3;
	else if (name == "April")
		mNum = 4;
	else if (name == "May")
		mNum = 5;
	else if (name == "June")
		mNum = 6;
	else if (name == "July")
		mNum = 7;
	else if (name == "August")
		mNum = 8;
	else if (name == "September")
		mNum = 9;
	else if (name == "October")
		mNum = 10;
	else if (name == "November")
		mNum = 11;
	else if (name == "December")
		mNum = 12;
	else
		mNum = 1;
}