/*
	Carter Reynolds

	Chapter 13 Lab 1

	Due Date: 11/9/2018

	Description:	This demo program should test the operator overload functions inside of the class numDays.
					This program will also test the values of a numdays object with incorrect values, called "incorrectValues".
				
	Side Note: I overloaded the stream insertion operator, and it worked! That is so cool, and time-saving!
					
*/

#include "numDays.h"

using namespace std;

numDays days;
double userChoice;

ostream& operator<<(ostream& osObject, const numDays& numDaysObj);

int main()
{
	cout << "numDays object days created. \n";
	cout << days;

	cout << endl << "Enter number of hours worked, answer cannot be less than nor equal to zero: \n";
	cin >> userChoice;
	days.setHours(userChoice);
	
	cout << endl << days << endl << endl;

	cout << "Now using the post increment operator on the numDays object (days++) \n";

	days++;

	cout << endl << endl << "The values of numDays type are now: \n";
	cout << endl << days << endl << endl;

	cout << "Now using the post decrement operator on the numDays object (days--) \n";
	days--;

	cout << endl << endl << "The values of numDays type are now: \n";
	cout << endl << days << endl << endl;

	cout << "Now creating the numDays object, incorrectValues(-22) \n" << endl;
	numDays incorrectValues(-22);
	
	cout << endl;

	cout << "days - incorrectValues = " << days - incorrectValues << endl << endl;

	cout << "Final values of the two classes are: \n";

	cout << "Days........ \n" << days << endl << "incorrectValues......... \n" << incorrectValues << endl;

	cout << endl;
	system("pause");
	return 0;
}

ostream& operator<<(ostream& osObject, const numDays& numDaysObj)
{
	cout << "Hours: " << numDaysObj.hours << endl;
	cout << "Days: " << numDaysObj.days << endl;

	return osObject;
}