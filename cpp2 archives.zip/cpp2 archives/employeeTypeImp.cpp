//***********************************************************************************************************************************************
//		
//		Carter Reynolds
//
//		Chapter 10 - Lab 2:
//
//		File name: employeeType.Imp.cpp
//
//		Description: 
//		This implementation file contains the source code for the functions of class employeeType.
//
//
//***********************************************************************************************************************************************


#include "employeeType.h";


employeeType::employeeType(string NAME, int ID, string DEPT, string POS)
{
	name = NAME;
	idNum = ID;
	department = DEPT;
	position = POS;
}

employeeType::employeeType(string NAME, int ID)
{
	name = NAME;
	idNum = ID;
	department = " ";
	position = " ";
}

employeeType::employeeType()
{
	name = " ";
	idNum = 0;
	department = " ";
	position = " ";
}

void employeeType::setName(string NAME)
{
	name = NAME;
}

void employeeType::setIDnum(int ID)
{
	idNum = ID;
}

void employeeType::setDept(string DEPT)
{
	department = DEPT;
}

void employeeType::setPos(string POS)
{
	position = POS;
}

string employeeType::getName()
{
	return name;
}

int employeeType::getIDnum()
{
	return idNum;
}

string employeeType::getDept()
{
	return department;
}

string employeeType::getPos()
{
	return position;
}
