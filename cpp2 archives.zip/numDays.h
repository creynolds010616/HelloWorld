#include <iostream>
#include <iomanip>
#include <string>
#pragma once

using namespace std;

class numDays
{
private:
	double hours, days;
	const int HOURS_PER_DAY = 8;

public:
	numDays();
	numDays(double);

	void setHours(double);
	void setDays(double);

	double getHours();
	double getDays();

	double operator+(const numDays &right);
	double operator-(const numDays &right);

	double operator++();
	double operator++(int);

	double operator--();
	double operator--(int);

	friend ostream& operator<<(ostream& osObject, const numDays&);
};

double numDays::operator+(const numDays &right) { return hours + right.hours; }
double numDays::operator-(const numDays &right) { return hours - right.hours; }

double numDays::operator++() { return hours++; }
double numDays::operator++(int n) { return ++hours; }

double numDays::operator--() { return hours--; }
double numDays::operator--(int n) { return --hours; }

numDays::numDays() { hours = 0.0; days = 0.0; }

numDays::numDays(double hrs) 
{ 
	hours = hrs; 
	
	if (hours > 0)
		days = hours / 8;
	else
	{
		while (hours < 0 || hours == 0)
		{
			cout << "Hours must be greater than zero. Retype hours worked below: \n";
			cin >> hours;
		}

		days = hours / 8;
	}
}

void numDays::setHours(double hrs) 
{ 
	hours = hrs; 
	
	if (hours > 0)
		days = hours / 8;
	else
	{
		while (hours < 0 || hours == 0)
		{
			cout << "Hours must be greater than zero. Retype hours worked below: \n";
			cin >> hours;
		}

		days = hours / 8;
	}
}

void numDays::setDays(double d)
{
	if (hours > 0)
		days = hours / 8;
	else
	{
		while (hours < 0 || hours == 0)
		{
			cout << "Hours must be greater than zero. Retype hours worked below: \n";
			cin >> hours;
		}

		days = hours / 8;
	}
	
}

double numDays::getHours() { return hours; }
double numDays::getDays()
{
	if (hours > 0)
		return hours / 8;
	else
	{
		while (hours < 0 || hours == 0)
		{
			cout << "Hours must be greater than zero. Retype hours worked below: \n";
			cin >> hours;
		}

		days = hours / 8;

		return days;
	}
}

