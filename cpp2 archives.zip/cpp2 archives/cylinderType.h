//******************************************************************************************************************************************
//		Carter Reynolds
//		
//		Chapter 11 - Lab Assignment 2				
//
//		Due: 10/10/2018
//	
//		File Name: cylinderType.h
//		
//		Description: This is the header file to define the class cylinderType, a derived class from circleType. This file also serves as the implementation file for the 
//					 class cylinderType due to the smaller number of functions.
//
//					 Overall, this class is intended to display the relationships of derived classes. 
//******************************************************************************************************************************************

#pragma once
#include "circleType.h"

using namespace std;

class cylinderType : public circleType
{
public:
	cylinderType();
	//Default constructor to initialize the members of this class.
	//Postcondition: lenght, width, and height = 0; 
	
	cylinderType(int l, int w, int h, double r);
	//Secondary constructor.
	//Postcondition: length, width, height, and radius are assigned to the parameters, respectively.

	//The following functions will assign the member the value of the respective parameter:
	void setRadius(double r);
	void setLength(int l);
	void setWidth(int w);
	void setHeight(int h);
	
	//The following functions will calculate and return the member in the function name:
	double getVolume();
	double getArea();
	double getRadius();
	int getLength();
	int getWidth();
	int getHeight();

	void getAll(cylinderType cyl); //Shortcut to display all members of this class.
	
private: 
	double area, volume, radius;
	int width, length, height;

};

cylinderType::cylinderType()
{
	int length = 0;
	int width = 0;
	int height = 0;
	double radius = 0.0;
	double area = 2 * 3.1416 * radius * (radius + height);
	double volume = 3.1416 * radius * radius * height;
}

cylinderType::cylinderType(int l, int w, int h, double r)
{
	length = l;
	width = w;
	height = h;
	radius = r;
	double area = 2 * 3.1416 * radius * (radius + height);
	double volume = 3.1416 * radius * radius * height;
}

void cylinderType::setLength(int l) { length = l; }

void cylinderType::setWidth(int w) { width = w; }

void cylinderType::setHeight(int h) { height = h; }

void cylinderType::setRadius(double r) { radius = r; }

int cylinderType::getLength() { return length; }

int cylinderType::getWidth() { return width; }

int cylinderType::getHeight() { return height; }

double cylinderType::getRadius() { return radius; }

double cylinderType::getArea() { return 2 * 3.1416 * radius * (radius + height); }

double cylinderType::getVolume() { return 3.1416 * radius * radius * height; }

void cylinderType::getAll(cylinderType cyl)
{
	cout << fixed << left << showpoint << setprecision(2);

	cout << "Volume: " << cyl.getVolume() << endl;
	cout << "Area: " << cyl.getArea() << endl;
	cout << endl;
	cout << "Length: " << cyl.getLength() << endl;
	cout << "Width: " << cyl.getWidth() << endl;
	cout << "Height: " << cyl.getHeight() << endl;
	cout << "Radius: " << cyl.getRadius() << endl;
}