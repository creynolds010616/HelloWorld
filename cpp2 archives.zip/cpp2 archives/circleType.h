//******************************************************************************************************************************************
//		Carter Reynolds
//		
//		Chapter 11 - Lab Assignment 2				
//
//		Due: 10/10/2018
//	
//		File Name: circleType.h
//		
//		Description: This is the header file to define the class circleType as per pages 689 and 690 in our textbook. 
//					 This file also serves as the implementation file for the class circleType due to the smaller number of functions.
//******************************************************************************************************************************************

#pragma once
#include <iostream>
#include <iomanip>
#include <string>

using namespace std; 

class circleType
{
public:
	void setRadius(double r);
	//Function to set the radius.
	//Postcondition: if (r >= 0) radius = r;
	//				 otherwise radius = 0;

	double getRadius();
	//Funtion to return the radius.
	//Postcondition: The value of radius is returned.

	double getArea();
	//Funtion to return the area of a circle.
	//Postcondition: Area is calculated and returned.

	double getCircumference();
	//Function to return the circumference of a circle.
	//Postcondition: Circumference is calculated and returned.
	
	circleType(double r = 0); 
	//Constructor with a default parameter.
	//Radius is set according to the parameter.
	//The default value of the radius is 0.0;
	//Postcondition: radius = r;

private:
	double radius;
};

void circleType::setRadius(double r)
{
	if (r >= 0)
		radius = r;
	else
		radius = 0;
}

double circleType::getRadius() { return radius; }

double circleType::getArea() { return 3.1416 * radius * radius; }

double circleType::getCircumference() { return 2 * 3.1416 * radius; }

circleType::circleType(double r) { setRadius(r); }