//***********************************************************************************************************************************************
//		
//		Carter Reynolds
//
//		Chapter 10 - Lab 2:
//
//		File name: test_main.cpp
//
//		Description: 
//		This is the demo program of the class employeeType. 
//		The program displays the members of each variable of employeeType before and after they have been configured.
//
//
//		The display functions were originally programmed as one function, but I got nervous and designated each class variable to have 
//		a corresponding display function.
//
//***********************************************************************************************************************************************


#include "employeeType.h";

using namespace std;

void displayE1(); //displays class employeeType e1
void displayE2(); //displays class employeeType e2
void displayE3(); //displays class employeeType e3


employeeType e1;													// constructor without parameters.
employeeType e2("Mark Jones", 39119);								// constructor with only name and idNumber parameters.
employeeType e3("Joy Rogers", 81774, "Manufacturing", "Engineer");	// constructor will all members having a corresponding parameter.

int main()
{
	//***********************************************************************************************************************************************
	// 
	//				Step 1:	display members of each class variable after their coresponding constructor.
	//
	//***********************************************************************************************************************************************
	
	cout << "Due to the large amount of information, the system will periodically sleep to allow sufficient reading time.";
	Sleep(10000);
	
	cout << endl;
	cout << "Displaying members of class employeeType variables (e1, e2, and e3) while using different constructors... \n";
	Sleep(5000);
	cout << endl;
	displayE1();
	
	Sleep(3000);
	cout << endl;
	
	displayE2();
	
	Sleep(3000);
	cout << endl;
	
	displayE3();

	cout << endl << "e1, e2, and e3 will now be configured via set functions (please scroll down on the screen). \n";

	//***********************************************************************************************************************************************
	// 
	//				Step 2:	configure the class variables via set methods
	//
	//***********************************************************************************************************************************************
	
	e1.setName("Susan Meyers");
	e1.setDept("Accounting");
	e1.setPos("CFO");
	e1.setIDnum(47899);

	//e2.setName("");
	e2.setDept("IT");
	e2.setPos("Programmer");
	//e2.setIDnum(39119);

	//e3.setName("");
	//e3.setDept("");
	//e3.setPos("");
	//e3.setIDnum(81774);

	
	Sleep(5000);
	cout << endl;
	cout << "class employeeType has been configured. \n";
	cout << endl << endl;
	Sleep(3000);

//***********************************************************************************************************************************************
// 
//				Step 3:	display members of each class variable via display function and get methods.
//
//***********************************************************************************************************************************************

	cout << "System will now display the configured variables." << endl;
	
	Sleep(3000);
	cout << endl;

	displayE1();
	
	Sleep(3000);
	cout << endl;
	
	displayE2();
	
	Sleep(3000);
	cout << endl;
	
	displayE3();
	
	cout << endl;
	cout << "End of program. \n";
	cout << endl;

	cout << endl;
	system("pause");
	return EXIT_SUCCESS;
}
//***********************************************************************************************************************************************
// 
//			custom functions
//
//***********************************************************************************************************************************************
void displayE1()
{
	cout << "employeeType e1 values are: \n" << endl;
	cout << "Name: " << e1.getName() << endl;
	cout << "ID Number: " << e1.getIDnum() << endl;
	cout << "Department: " << e1.getDept() << endl;
	cout << "Position: " << e1.getPos() << endl;
}
void displayE2()
{
	cout << "employeeType e2 values are: \n" << endl;
	cout << "Name: " << e2.getName() << endl;
	cout << "ID Number: " << e2.getIDnum() << endl;
	cout << "Department: " << e2.getDept() << endl;
	cout << "Position: " << e2.getPos() << endl;
}
void displayE3()
{
	cout << "employeeType e3 values are: \n" << endl;
	cout << "Name: " << e3.getName() << endl;
	cout << "ID Number: " << e3.getIDnum() << endl;
	cout << "Department: " << e3.getDept() << endl;
	cout << "Position: " << e3.getPos() << endl;		
}