#include <iostream>
#include <iomanip>
using namespace std; 

int calMinorGrade();

int main()
{
	calMinorGrade();
	
	cout << endl; 
	system("pause");
	return 0;
}

int calMinorGrade()
{
	// ASK USER FOR ARRAY SIZE/NUMBER OF GRADES
	// int ARRAY_SIZE; 
	
	// cout << "How many grades will be averaged? \n"; 
	// cin >> ARRAY_SIZE;

	// const int CONST_ARRAY_SIZE
	double gradesArray[5]; //change index < 5 to index < CONST_ARRAY_SIZE

	cout << "Enter the grades to be averaged one at a time below (press enter after each grade): \n"; 
	//accept input
	for (int index = 0; index < 5; index++) //change index < 5 to index < CONST_ARRAY_SIZE
	{
		cin >> gradesArray[index]; // enter 20, 30, 40, 50, 60 to receive answer of 12
	}
	
	//calculate avg * .30
	double gradeTotal = 0.00;

	for (int index = 0; index < 5; index++)
	{
		gradeTotal = gradesArray[index] + gradeTotal;
	}

	double gradeAverage = gradeTotal / 5;

	double gradeAverage30 = gradeAverage * .30;

	cout << endl << "The average of the grades multiplied by 30 percent is: " << gradeAverage30 << endl; 

	cout << endl;
	return 0;
}