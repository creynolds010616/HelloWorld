#include <iostream>

using namespace std; 

int main()
{
	double gradesArray[5]; 

	for (int index = 0; index < 5; index++)
	{
		cin >> gradesArray[index];
	}

	double gradeTotal = 0.00;

	for (int index = 0; index < 5; index++)
	{
		gradeTotal = gradesArray[index] + gradeTotal;
	}

	double gradeAverage = gradeTotal / 5; 

	double gradeAverage30 = gradeAverage * .30;

	cout << gradeAverage30; 

	cout << endl;
	system("pause");
	return 0;
}