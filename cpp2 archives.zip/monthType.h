/*
Carter Reynolds

Programming Assignment IV - Overloading

Due Date: 11/14/2018

File Name: monthType.h

Description:

*/

#pragma once
#include <iostream>
#include <iomanip>
#include <string>

using namespace std; 

class monthType
{
public:
	monthType();
	monthType(string m);
	monthType(int n);

	void setName(string m);
	void setNumber(int n);

	void updateName(); 
	void updateNumber();

	friend void inc_next_month_Print(monthType& monthTypeObj);
	friend void dec_next_month_Print(monthType& monthTypeObj);

	string getName();
	int getNumber();

	friend ostream& operator<<(ostream& osObject, const monthType& monthTypeObj);
	
	friend monthType operator++(monthType&, int u);
	friend monthType operator--(monthType&, int u);

protected:
	string name;
	int mNum; // should be within 1 and 12.
};